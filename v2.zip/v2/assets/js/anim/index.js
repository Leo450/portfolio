let anim = new Anim();

anim.run();